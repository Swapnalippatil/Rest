package JUnitTest;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.test.LogClass;
import com.test.MathProvider;

public class MockMathProviderTest {
	
	@Mock
	private LogClass logger;
	
	@InjectMocks
	private JunitMathProviderTest providerTester;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}
	
	/*@Test
	public void test() {
		when(logger.printResult(any(MathProvider.class))).th
		;
	}*/

}
