package JUnitTest;

import static org.junit.Assert.*;
import static org.testng.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.*;
import org.mockito.Spy;

import com.test.LogClass;
import com.test.MathProvider;

public class JunitMathProviderTest {

	//MathProvider providerTester = new MathProvider();
	
	@Mock
	private LogClass logger;
	
	@InjectMocks
	private MathProvider providerTester = new MathProvider();
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void MathTest() {
		
		MathProvider spyProvider = Mockito.spy(providerTester);
		
		
		
		System.out.println("starting test .."+ new Object() {}.getClass().getEnclosingMethod().getName());
		int firstNumber = 10;
		int secondNumber=30;
		//Mockito.doReturn(firstNumber).when(spyProvider).incrementNumber(Mockito.any());
		Mockito.doReturn(firstNumber).when(spyProvider).incrementNumber(firstNumber); 
		
		assertEquals((firstNumber + secondNumber), spyProvider.addition(firstNumber, secondNumber));
		System.out.println("Ending test .." + new Object(){}.getClass().getEnclosingMethod().getName());
		
		verify(logger).printResult(10);
		verify(logger, times(1)).printResult(10);
	}
	
	

}
