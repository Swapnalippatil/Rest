package com.test;

import org.hamcrest.Matcher;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static io.restassured.path.json.JsonPath.from;
import static org.testng.Assert.assertEquals;
import static org.hamcrest.MatcherAssert.assertThat;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class PostRequestTest {
	public static Response response;
	public static String jsonAsString;
	
	@BeforeClass
	  public void setBaseUri () {
	    RestAssured.baseURI = "http://localhost:3000";	    
	  }

	@Test
	  public void postString () {
	    
	    given().body ("{\"id\":\"3\","
	    +"\"title\":\"Hello India\","
	    +"\"author\":\"StaffWriter\"}")
	    .when ()
	    .contentType (ContentType.JSON)
	    .post ("/posts");
	      
	  }
	
	@Test
	public void PostTest() {
		given().
        
        param("id", "4").
        param("title", "Selenium").
    when().
        post("/posts").
    then().
        contentType(ContentType.JSON).
        body("result.message", Matchers.equalTo("success"));
	}

	@Test
	public void callGet() {
		response =
	            when().
	                get("/posts").
	            then().
	                contentType(ContentType.JSON).  // check that the content type return from the API is JSON
	            extract().response(); // extract the response

	        // We convert the JSON response to a string, and save it in a variable called 'jsonAsString'
		jsonAsString = response.asString();
	}

	@Test
	public void checkForNumberOfEntries()
	{
	    // first we put our 'jsonAsString' into an ArrayList of Maps of type <String, ?>
	    ArrayList<Map<String,?>> jsonAsArrayList = from(jsonAsString).get("");

	    // now we count the number of entries in the JSON file, each entry is 1 ride
	    
	    Assert.assertEquals(jsonAsArrayList.size(), 3);
	}

	@Test
	public void checkforEntries2()
	{
		response =
	            when().
	                get("/posts");
		List<String> list = from(jsonAsString).get("id");
		
		System.out.println("Size: "+list.size());
	}
}
