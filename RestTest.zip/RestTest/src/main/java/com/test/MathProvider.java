package com.test;

public class MathProvider {
	LogClass logger = new LogClass();
	public int substract(int num1, int num2) {
		return(num1-num2);
	}
	
	public int addition(int num1, int num2) {
		int num_new = incrementNumber(num1);
		System.out.println("Running...");
		logger.printResult(num_new);
		return(num_new+num2);
	}

	public int multiply(int num1, int num2) {
		return(num1*num2);
	}
	
	public int incrementNumber(int num) {
		return num * 10;
	}
}



