package com.test;

import static org.hamcrest.Matchers.*;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.RestAssured.*;

public class GetRequestTest {

	@BeforeClass
	public void setBaseUri() {

		RestAssured.baseURI = "http://localhost:3000";
	}

	@Test
	public void test01() {
		Response res=
		given().
			queryParam("title", "Hello Mumbai").
		when().
			get("/posts").
		then().
			contentType(ContentType.JSON).
			extract().response();
		System.out.println(res.asString());
	}

	@Test
	public void test02() {
		Response res = given().param("id", 2).when().get("/posts").then()
				// .body("author", is("StaffWriter"))
				.extract().response();

		System.out.println(res.asString());
		System.out.println(res.path("title"));

	}

}
