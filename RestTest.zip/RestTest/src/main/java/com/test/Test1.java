package com.test;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import static io.restassured.path.json.JsonPath.from;
//import static com.jayway.restassured.path.json.JsonPath.from;

import java.util.List;
import org.hamcrest.Matchers;
import static org.hamcrest.MatcherAssert.assertThat;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;

public class Test1 {
	@Test
	// http://services.groupkt.com/country/search?text=islands
	public void testMethod1() {
		  given(). get("http://jsonplaceholder.typicode.com/users/1"). then().
		  body("company.name", Matchers.equalTo("Romaguera-Crona")). //log().all();
		  assertThat().body(matchesJsonSchemaInClasspath("Schema.json"));
	}
	
	@Test
	public void testMethod2() {
	String str =
		given().get("http://services.groupkt.com/state/get/IND/JK").then()
				.body("RestResponse.result.name", is("Jammu and Kashmir")).root("RestResponse.result")
				.body("name", is("Jammu and Kashmir")).body("country", is("IND")).detachRoot("result")
				.body("result.capital", is("Srinagar Jammu")).
				extract().path("RestResponse.result.country");
	System.out.println(str);
	}
	
	@Test
	public void TestMethod3()
	{
		given().get("http://services.groupkt.com/state/get/IND/all").then()
		.body("RestResponse.result.name",hasItems("Jharkhand","Kerala","Maharashtra"));
		
	}
	
	@Test
	public void TestMethod4()
	{
			
		given().get("http://services.groupkt.com/state/get/IND/all").then()
		.body("RestResponse.result.name.collect { it.length() }.sum()",greaterThan(369));
	}	
	
	@Test
	public void TestMethod5()
	{
		String response = get("http://services.groupkt.com/state/get/IND/all").asString();
		List<String> list = from(response).getList("RestResponse.result.name");
		
		System.out.println("Size: "+list.size());
		System.out.println("Lsit: "+list);
	
		/*
		 * //given().
		 * config(RestAssured.config().xmlConfig(xmlConfig().declareNamespace("test",
		 * "http://localhost/"))). when(). get("/namespace-example"). then().
		 * body("foo.bar.text()", equalTo("sudo make me a sandwich!")).
		 * body(":foo.:bar.text()", equalTo("sudo ")). body("foo.test:bar.text()",
		 * equalTo("make me a sandwich!"));
		 */
	}

	/*
	 * @Test public void testMethod1() { given().param("id",
	 * 1).get("http://jsonplaceholder.typicode.com/users").then().statusCode(200).
	 * log().all(); }
	 * 
	 * @Test public void testMethod2() { given().pathParam("id",
	 * 1).get("http://jsonplaceholder.typicode.com/users/{id}").then().statusCode(
	 * 200).log() .all(); }
	 * 
	 * @Test public void testMethod3() { Response res = given().pathParam("id",
	 * 1).get("http://jsonplaceholder.typicode.com/users/{id}");
	 * System.out.println("res.path(\"id\") = " + res.path("id")); //
	 * res.then().body("name", Matchers.equalTo("Leanne Gredweaham")).body("id", //
	 * Matchers.equalTo(1)); res.then().body("name",
	 * Matchers.equalTo("Leanne Gredweaham"), "id", Matchers.equalTo(1)); }
	 * 
	 * @Test public void schemaValidations() {
	 * given().get("http://jsonplaceholder.typicode.com/users/1").then()
	 * .body(JsonSchemaValidator.matchesJsonSchemaInClasspath("Schema.json")).log().
	 * all(); }
	 * 
	 * @Test public void basicAuth() { given().auth().basic("postman",
	 * "password").get("https://postman-echo.com/basic-auth").then().statusCode(200)
	 * ; }
	 */

}
