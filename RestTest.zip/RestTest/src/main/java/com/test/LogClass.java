package com.test;

public class LogClass {
	
	public void printResult(int num1) {
		System.out.println(num1);
	}
	
}
