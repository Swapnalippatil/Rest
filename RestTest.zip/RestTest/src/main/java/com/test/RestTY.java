package com.test;

import org.hamcrest.Matcher;
import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.config.ParamConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.bytebuddy.matcher.EqualityMatcher;

import static io.restassured.RestAssured.*;

public class RestTY {

	@Test
	public void testMethod() {
		given().get("http://jsonplaceholder.typicode.com/users").then().statusCode(200).log().all();
	}

	@Test
	public void testMethod1() {
		given().param("id", 1).get("http://jsonplaceholder.typicode.com/users").then().statusCode(200).log().all();
	}

	@Test
	public void testMethod2() {
		given().pathParam("id", 1).get("http://jsonplaceholder.typicode.com/users/{id}").then().statusCode(200).log()
				.all();
	}

	@Test
	public void testMethod3() {
		Response res = given().pathParam("id", 1).get("http://jsonplaceholder.typicode.com/users/{id}");
		System.out.println("res.path(\"id\") = " + res.path("id"));
		// res.then().body("name", Matchers.equalTo("Leanne Gredweaham")).body("id",
		// Matchers.equalTo(1));
		res.then().body("name", Matchers.equalTo("Leanne Gredweaham"), "id", Matchers.equalTo(1));
	}

	@Test
	public void schemaValidations() {
		given().get("http://jsonplaceholder.typicode.com/users/1").then()
				.body(JsonSchemaValidator.matchesJsonSchemaInClasspath("Schema.json")).log().all();
	}

	@Test
	public void basicAuth() {
		given().auth().basic("postman", "password").get("https://postman-echo.com/basic-auth").then().statusCode(200);
	}
}
